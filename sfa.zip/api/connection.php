<?php
    //infinityfree
    //$conn = mysqli_connect('185.27.134.33', 'epiz_32096924', 'pwDH2i7trXNN', 'epiz_32096924_cdis');
    //000webhost
    //$conn = new mysqli("localhost", "id19205512_root", "yH&+ui~(io%%I]7V", "id19205512_sfa");
    //db4free alsace datbase
    //$conn = mysqli_connect('db4free.net', 'sfa1database', '12345678', 'sfa1database', '3306 ');
    //localhost     
    $conn = mysqli_connect('localhost', 'root', '', 'sfa');
?>
